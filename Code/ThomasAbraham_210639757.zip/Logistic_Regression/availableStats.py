# Dictionary holding stats that are analyzed for each game and their type

availableStats = {'W_PCT':'Base',
                  'REB':'Base',
                  'TOV':'Base',
                  'PLUS_MINUS':'Base',
                  'OFF_RATING':'Advanced',
                  'DEF_RATING':'Advanced',
                  'TS_PCT':'Advanced'}